 <?php
    require './DontEdit/index.php';
